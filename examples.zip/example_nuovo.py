from pydojo import *

#create game display
SCREEN(800, 600)



#update screen and events queue
UPDATE()

#wait
sleep(1)
